package com.example.bdaywisher

import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var listBox: LinearLayout
    private lateinit var timeBtn: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        fun tv(t: String, size: Float = 16f) = TextView(this).apply { text = t; textSize = size }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }

        root.addView(tv("Birthday Wisher", 22f))
        root.addView(btn("1) Accessibility ON karo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(btn("2) Battery 'Unrestricted' karo") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        timeBtn = btn("") {
            TimePickerDialog(this, { _, hh, mm ->
                Store.setTime(this, hh, mm)
                Scheduler.schedule(this)
                showTime()
            }, Store.hour(this), Store.minute(this), true).show()
        }
        root.addView(timeBtn)
        showTime()

        root.addView(tv("\nNaya dost jodo", 18f))
        val name = EditText(this).apply { hint = "Naam" }
        val num = EditText(this).apply { hint = "Mobile number"; inputType = InputType.TYPE_CLASS_PHONE }
        val day = EditText(this).apply { hint = "Birthday: Din (1-31)"; inputType = InputType.TYPE_CLASS_NUMBER }
        val mon = EditText(this).apply { hint = "Birthday: Mahina (1-12)"; inputType = InputType.TYPE_CLASS_NUMBER }
        val msg = EditText(this).apply {
            hint = "Wish message"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
        }
        listOf(name, num, day, mon, msg).forEach { root.addView(it) }
        root.addView(btn("Save karo") {
            val digits = num.text.toString().filter { it.isDigit() }
            val n = if (digits.length == 10) "91$digits" else digits
            val d = day.text.toString().toIntOrNull() ?: 0
            val m = mon.text.toString().toIntOrNull() ?: 0
            if (name.text.isBlank() || n.length < 11 || d !in 1..31 || m !in 1..12 || msg.text.isBlank()) {
                Toast.makeText(this, "Sab detail sahi bharo", Toast.LENGTH_SHORT).show()
            } else {
                val l = Store.load(this)
                l.add(Contact(name.text.toString().trim(), n, d, m, msg.text.toString().trim()))
                Store.save(this, l)
                listOf(name, num, day, mon, msg).forEach { it.text.clear() }
                refresh()
            }
        })

        root.addView(tv("\nSaved list", 18f))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)
        refresh()

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        Scheduler.schedule(this)
    }

    private fun showTime() {
        timeBtn.text = "3) Bhejne ka time: %02d:%02d (badalne ke liye tap)".format(Store.hour(this), Store.minute(this))
    }

    private fun refresh() {
        listBox.removeAllViews()
        val l = Store.load(this)
        l.forEachIndexed { idx, c ->
            listBox.addView(TextView(this).apply {
                text = "\n${c.name}  |  +${c.number}  |  ${c.day}/${c.month}\n${c.msg}"
                textSize = 15f
            })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(Button(this).apply {
                text = "Abhi test bhejo"
                setOnClickListener { Sender.start(this@MainActivity, listOf(c)) }
            })
            row.addView(Button(this).apply {
                text = "Delete"
                setOnClickListener {
                    val cur = Store.load(this@MainActivity)
                    cur.removeAt(idx)
                    Store.save(this@MainActivity, cur)
                    refresh()
                }
            })
            listBox.addView(row)
        }
    }
}
