package com.example.bdaywisher

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat

object Sender {
    val queue = ArrayDeque<Contact>()
    var current: Contact? = null

    private fun pkgFor(c: Context): String? {
        for (p in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                c.packageManager.getPackageInfo(p, 0)
                return p
            } catch (e: Exception) { }
        }
        return null
    }

    fun buildIntent(c: Context, ct: Contact): Intent {
        val num = ct.number.filter { it.isDigit() }
        val url = "https://wa.me/$num?text=" + Uri.encode(ct.msg)
        return Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            pkgFor(c)?.let { setPackage(it) }
        }
    }

    fun start(c: Context, list: List<Contact>) {
        queue.clear()
        queue.addAll(list)
        next(c)
    }

    fun next(c: Context) {
        val ct = queue.removeFirstOrNull() ?: run { current = null; return }
        current = ct
        val svc = WishService.instance
        if (svc != null) {
            svc.begin()
            svc.startActivity(buildIntent(c, ct))
        } else {
            // Accessibility ON nahi hai -> notification bhejo, tap karke bhejna padega
            notifyManual(c, ct)
            while (queue.isNotEmpty()) notifyManual(c, queue.removeFirst())
        }
    }

    fun notifyManual(c: Context, ct: Contact) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("bw", "Birthdays", NotificationManager.IMPORTANCE_HIGH))
        }
        val id = ct.number.hashCode()
        val pi = PendingIntent.getActivity(
            c, id, buildIntent(c, ct),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(c, "bw")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Aaj ${ct.name} ka birthday hai")
            .setContentText("Tap karke wish bhejo")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
    }
}
