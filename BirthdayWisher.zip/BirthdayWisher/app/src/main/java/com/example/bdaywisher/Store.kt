package com.example.bdaywisher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Contact(val name: String, val number: String, val day: Int, val month: Int, val msg: String)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("bw", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Contact> {
        val a = JSONArray(p(c).getString("list", "[]"))
        val out = mutableListOf<Contact>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(Contact(o.getString("n"), o.getString("p"), o.getInt("d"), o.getInt("m"), o.getString("t")))
        }
        return out
    }

    fun save(c: Context, l: List<Contact>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("n", it.name).put("p", it.number).put("d", it.day).put("m", it.month).put("t", it.msg))
        }
        p(c).edit().putString("list", a.toString()).apply()
    }

    fun hour(c: Context) = p(c).getInt("h", 9)
    fun minute(c: Context) = p(c).getInt("mi", 0)
    fun setTime(c: Context, h: Int, m: Int) = p(c).edit().putInt("h", h).putInt("mi", m).apply()
}
