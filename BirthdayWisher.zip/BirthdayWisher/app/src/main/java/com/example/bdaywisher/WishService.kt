package com.example.bdaywisher

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class WishService : AccessibilityService() {
    companion object {
        var instance: WishService? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private var waiting = false
    private val timeout = Runnable { finish(false) }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    fun begin() {
        waiting = true
        h.removeCallbacks(timeout)
        h.postDelayed(timeout, 25000)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (!waiting) return
        val root = rootInActiveWindow ?: return
        if (findSend(root) != null) {
            waiting = false
            h.removeCallbacks(timeout)
            h.postDelayed({
                val r = rootInActiveWindow
                val btn = if (r != null) findSend(r) else null
                if (btn != null) {
                    btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    h.postDelayed({ finish(true) }, 2500)
                } else {
                    finish(false)
                }
            }, 1500)
        }
    }

    private fun findSend(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            val n = root.findAccessibilityNodeInfosByViewId(id)
            if (!n.isNullOrEmpty()) return n[0]
        }
        for (t in listOf("Send", "भेजें")) {
            val n = root.findAccessibilityNodeInfosByText(t)
            val m = n?.firstOrNull {
                it.isClickable && it.contentDescription?.toString().equals(t, ignoreCase = true)
            }
            if (m != null) return m
        }
        return null
    }

    private fun finish(ok: Boolean) {
        waiting = false
        h.removeCallbacks(timeout)
        if (!ok) Sender.current?.let { Sender.notifyManual(this, it) }
        performGlobalAction(GLOBAL_ACTION_BACK)
        h.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 800)
        if (Sender.queue.isNotEmpty()) {
            h.postDelayed({ Sender.next(this) }, (60000L..120000L).random())
        }
    }
}
